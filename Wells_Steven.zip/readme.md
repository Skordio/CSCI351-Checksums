# Steven Wells CSCI 351 Programming Assignment

This is my submission for the programming assignment.

## Running the script

Run the program using the -f argument to specify the packet K12 file:

```bash
python3 .\process_tcp_packet.py -f tcp_packet.txt
```